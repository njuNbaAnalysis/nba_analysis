package test.data;

import java.io.Serializable;

public class PlayerNormalInfo
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String name;
  private int age;
  private String teamName;
  private int numOfGame;
  private int start;
  private double rebound;
  private double assist;
  private double minute;
  private double efficiency;
  private double shot;
  private double three;
  private double penalty;
  private double offend;
  private double defend;
  private double steal;
  private double blockShot;
  private double fault;
  private double foul;
  private double point;

  public String getName()
  {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public int getAge() {
    return this.age;
  }

  public void setAge(int age) {
    this.age = age;
  }

  public String getTeamName() {
    return this.teamName;
  }

  public void setTeamName(String teamName) {
    this.teamName = teamName;
  }

  public int getNumOfGame() {
    return this.numOfGame;
  }

  public void setNumOfGame(int numOfGame) {
    this.numOfGame = numOfGame;
  }

  public int getStart() {
    return this.start;
  }

  public void setStart(int start) {
    this.start = start;
  }

  public double getRebound() {
    return this.rebound;
  }

  public void setRebound(double rebound) {
    this.rebound = rebound;
  }

  public double getAssist() {
    return this.assist;
  }

  public void setAssist(double assist) {
    this.assist = assist;
  }

  public double getMinute() {
    return this.minute;
  }

  public void setMinute(double minute) {
    this.minute = minute;
  }

  public double getEfficiency() {
    return this.efficiency;
  }

  public void setEfficiency(double efficiency) {
    this.efficiency = efficiency;
  }

  public double getShot() {
    return this.shot;
  }

  public void setShot(double shot) {
    this.shot = shot;
  }

  public double getThree() {
    return this.three;
  }

  public void setThree(double three) {
    this.three = three;
  }

  public double getPenalty() {
    return this.penalty;
  }

  public void setPenalty(double penalty) {
    this.penalty = penalty;
  }

  public double getOffend() {
    return this.offend;
  }

  public void setOffend(double offend) {
    this.offend = offend;
  }

  public double getDefend() {
    return this.defend;
  }

  public void setDefend(double defend) {
    this.defend = defend;
  }

  public double getSteal() {
    return this.steal;
  }

  public void setSteal(double steal) {
    this.steal = steal;
  }

  public double getBlockShot() {
    return this.blockShot;
  }

  public void setBlockShot(double blockShot) {
    this.blockShot = blockShot;
  }

  public double getFault() {
    return this.fault;
  }

  public void setFault(double fault) {
    this.fault = fault;
  }

  public double getFoul() {
    return this.foul;
  }

  public void setFoul(double foul) {
    this.foul = foul;
  }

  public double getPoint() {
    return this.point;
  }

  public void setPoint(double point) {
    this.point = point;
  }

  public String toString()
  {
    StringBuilder stringBuilder = new StringBuilder();
    String ln = "\n";
    stringBuilder.append(getName()).append(ln);
    stringBuilder.append(getTeamName()).append(ln);
    stringBuilder.append(getNumOfGame()).append(ln);
    stringBuilder.append(getStart()).append(ln);
    stringBuilder.append(getRebound()).append(ln);
    stringBuilder.append(getAssist()).append(ln);
    stringBuilder.append(getMinute()).append(ln);
    stringBuilder.append(getEfficiency()).append(ln);
    stringBuilder.append(getShot()).append(ln);
    stringBuilder.append(getThree()).append(ln);
    stringBuilder.append(getPenalty()).append(ln);
    stringBuilder.append(getOffend()).append(ln);
    stringBuilder.append(getDefend()).append(ln);
    stringBuilder.append(getSteal()).append(ln);
    stringBuilder.append(getBlockShot()).append(ln);
    stringBuilder.append(getFault()).append(ln);
    stringBuilder.append(getFoul()).append(ln);
    stringBuilder.append(getPoint()).append(ln);
    return stringBuilder.toString();
  }
}