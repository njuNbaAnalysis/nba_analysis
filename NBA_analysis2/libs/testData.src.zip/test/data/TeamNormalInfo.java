package test.data;

import java.io.Serializable;

public class TeamNormalInfo
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String teamName;
  private double three;
  private int numOfGame;
  private double shot;
  private double penalty;
  private double offendRebound;
  private double defendRebound;
  private double rebound;
  private double assist;
  private double fault;
  private double steal;
  private double blockShot;
  private double foul;
  private double point;

  public String getTeamName()
  {
    return this.teamName;
  }

  public void setTeamName(String teamName) {
    this.teamName = teamName;
  }

  public double getThree() {
    return this.three;
  }

  public void setThree(double three) {
    this.three = three;
  }

  public int getNumOfGame() {
    return this.numOfGame;
  }

  public void setNumOfGame(int numOfGame) {
    this.numOfGame = numOfGame;
  }

  public double getShot() {
    return this.shot;
  }

  public void setShot(double shot) {
    this.shot = shot;
  }

  public double getPenalty() {
    return this.penalty;
  }

  public void setPenalty(double penalty) {
    this.penalty = penalty;
  }

  public double getOffendRebound() {
    return this.offendRebound;
  }

  public void setOffendRebound(double offendRebound) {
    this.offendRebound = offendRebound;
  }

  public double getDefendRebound() {
    return this.defendRebound;
  }

  public void setDefendRebound(double defendRebound) {
    this.defendRebound = defendRebound;
  }

  public double getRebound() {
    return this.rebound;
  }

  public void setRebound(double rebound) {
    this.rebound = rebound;
  }

  public double getAssist() {
    return this.assist;
  }

  public void setAssist(double assist) {
    this.assist = assist;
  }

  public double getFault() {
    return this.fault;
  }

  public void setFault(double fault) {
    this.fault = fault;
  }

  public double getSteal() {
    return this.steal;
  }

  public void setSteal(double steal) {
    this.steal = steal;
  }

  public double getBlockShot() {
    return this.blockShot;
  }

  public void setBlockShot(double blockShot) {
    this.blockShot = blockShot;
  }

  public double getFoul() {
    return this.foul;
  }

  public void setFoul(double foul) {
    this.foul = foul;
  }

  public double getPoint() {
    return this.point;
  }

  public void setPoint(double point) {
    this.point = point;
  }

  public String toString()
  {
    StringBuilder stringBuilder = new StringBuilder();
    String ln = "\n";
    stringBuilder.append(getTeamName()).append(ln);
    stringBuilder.append(getThree()).append(ln);
    stringBuilder.append(getNumOfGame()).append(ln);
    stringBuilder.append(getShot()).append(ln);
    stringBuilder.append(getPenalty()).append(ln);
    stringBuilder.append(getOffendRebound()).append(ln);
    stringBuilder.append(getDefendRebound()).append(ln);
    stringBuilder.append(getRebound()).append(ln);
    stringBuilder.append(getAssist()).append(ln);
    stringBuilder.append(getFault()).append(ln);
    stringBuilder.append(getSteal()).append(ln);
    stringBuilder.append(getBlockShot()).append(ln);
    stringBuilder.append(getFoul()).append(ln);
    stringBuilder.append(getPoint()).append(ln);
    return stringBuilder.toString();
  }
}