package test.data;

import java.io.Serializable;

public class TeamHighInfo
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String teamName;
  private double winRate;
  private double offendRound;
  private double offendEfficient;
  private double defendEfficient;
  private double offendReboundEfficient;
  private double defendReboundEfficient;
  private double stealEfficient;
  private double assistEfficient;

  public String getTeamName()
  {
    return this.teamName;
  }

  public void setTeamName(String teamName) {
    this.teamName = teamName;
  }

  public double getWinRate() {
    return this.winRate;
  }

  public void setWinRate(double winRate) {
    this.winRate = winRate;
  }

  public double getOffendRound() {
    return this.offendRound;
  }

  public void setOffendRound(double offendRound) {
    this.offendRound = offendRound;
  }

  public double getOffendEfficient() {
    return this.offendEfficient;
  }

  public void setOffendEfficient(double offendEfficient) {
    this.offendEfficient = offendEfficient;
  }

  public double getDefendEfficient() {
    return this.defendEfficient;
  }

  public void setDefendEfficient(double defendEfficient) {
    this.defendEfficient = defendEfficient;
  }

  public double getOffendReboundEfficient() {
    return this.offendReboundEfficient;
  }

  public void setOffendReboundEfficient(double offendReboundEfficient) {
    this.offendReboundEfficient = offendReboundEfficient;
  }

  public double getDefendReboundEfficient() {
    return this.defendReboundEfficient;
  }

  public void setDefendReboundEfficient(double defendReboundEfficient) {
    this.defendReboundEfficient = defendReboundEfficient;
  }

  public double getStealEfficient() {
    return this.stealEfficient;
  }

  public void setStealEfficient(double stealEfficient) {
    this.stealEfficient = stealEfficient;
  }

  public double getAssistEfficient() {
    return this.assistEfficient;
  }

  public void setAssistEfficient(double assistEfficient) {
    this.assistEfficient = assistEfficient;
  }

  public String toString()
  {
    StringBuilder stringBuilder = new StringBuilder();
    String ln = "\n";
    stringBuilder.append(getTeamName()).append(ln);
    stringBuilder.append(getWinRate()).append(ln);
    stringBuilder.append(getOffendRound()).append(ln);
    stringBuilder.append(getOffendEfficient()).append(ln);
    stringBuilder.append(getDefendEfficient()).append(ln);
    stringBuilder.append(getOffendReboundEfficient()).append(ln);
    stringBuilder.append(getDefendReboundEfficient()).append(ln);
    stringBuilder.append(getStealEfficient()).append(ln);
    stringBuilder.append(getAssistEfficient()).append(ln);
    return stringBuilder.toString();
  }
}