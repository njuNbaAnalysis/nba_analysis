package test.data;

import java.io.Serializable;

public class PlayerKingInfo
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String name;
  private String teamName;
  private String position;
  private String field;
  private double value;

  public String getName()
  {
    return this.name;
  }
  public void setName(String name) {
    this.name = name;
  }
  public String getTeamName() {
    return this.teamName;
  }
  public void setTeamName(String teamName) {
    this.teamName = teamName;
  }
  public String getPosition() {
    return this.position;
  }
  public void setPosition(String position) {
    this.position = position;
  }
  public String getField() {
    return this.field;
  }
  public void setField(String field) {
    this.field = field;
  }
  public double getValue() {
    return this.value;
  }
  public void setValue(double value) {
    this.value = value;
  }

  public String toString()
  {
    StringBuilder stringBuilder = new StringBuilder();
    String ln = "\n";
    stringBuilder.append(getName()).append(ln);
    stringBuilder.append(getTeamName()).append(ln);
    stringBuilder.append(getPosition()).append(ln);
    stringBuilder.append(getField()).append(ln);
    stringBuilder.append(getValue()).append(ln);
    return stringBuilder.toString();
  }
}