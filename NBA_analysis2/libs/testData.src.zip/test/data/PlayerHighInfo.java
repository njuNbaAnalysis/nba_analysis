package test.data;

import java.io.Serializable;

public class PlayerHighInfo
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String name;
  private String position;
  private String teamName;
  private String league;
  private double gmSc;
  private double realShot;
  private double shotEfficient;
  private double reboundEfficient;
  private double offendReboundEfficient;
  private double defendReboundEfficient;
  private double assistEfficient;
  private double stealEfficient;
  private double blockShotEfficient;
  private double faultEfficient;
  private double frequency;

  public String getName()
  {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getPosition() {
    return this.position;
  }

  public void setPosition(String position) {
    this.position = position;
  }

  public String getTeamName() {
    return this.teamName;
  }

  public void setTeamName(String teamName) {
    this.teamName = teamName;
  }

  public String getLeague() {
    return this.league;
  }

  public void setLeague(String league) {
    this.league = league;
  }

  public double getGmSc() {
    return this.gmSc;
  }

  public void setGmSc(double gmSc) {
    this.gmSc = gmSc;
  }

  public double getRealShot() {
    return this.realShot;
  }

  public void setRealShot(double realShot) {
    this.realShot = realShot;
  }

  public double getShotEfficient() {
    return this.shotEfficient;
  }

  public void setShotEfficient(double shotEfficient) {
    this.shotEfficient = shotEfficient;
  }

  public double getReboundEfficient() {
    return this.reboundEfficient;
  }

  public void setReboundEfficient(double reboundEfficient) {
    this.reboundEfficient = reboundEfficient;
  }

  public double getOffendReboundEfficient() {
    return this.offendReboundEfficient;
  }

  public void setOffendReboundEfficient(double offendReboundEfficient) {
    this.offendReboundEfficient = offendReboundEfficient;
  }

  public double getDefendReboundEfficient() {
    return this.defendReboundEfficient;
  }

  public void setDefendReboundEfficient(double defendReboundEfficient) {
    this.defendReboundEfficient = defendReboundEfficient;
  }

  public double getAssistEfficient() {
    return this.assistEfficient;
  }

  public void setAssistEfficient(double assistEfficient) {
    this.assistEfficient = assistEfficient;
  }

  public double getStealEfficient() {
    return this.stealEfficient;
  }

  public void setStealEfficient(double stealEfficient) {
    this.stealEfficient = stealEfficient;
  }

  public double getBlockShotEfficient() {
    return this.blockShotEfficient;
  }

  public void setBlockShotEfficient(double blockShotEfficient) {
    this.blockShotEfficient = blockShotEfficient;
  }

  public double getFaultEfficient() {
    return this.faultEfficient;
  }

  public void setFaultEfficient(double faultEfficient) {
    this.faultEfficient = faultEfficient;
  }

  public double getFrequency() {
    return this.frequency;
  }

  public void setFrequency(double frequency) {
    this.frequency = frequency;
  }

  public String toString()
  {
    StringBuilder stringBuilder = new StringBuilder();
    String ln = "\n";
    stringBuilder.append(getName()).append(ln);
    stringBuilder.append(getPosition()).append(ln);
    stringBuilder.append(getTeamName()).append(ln);
    stringBuilder.append(getLeague()).append(ln);
    stringBuilder.append(getGmSc()).append(ln);
    stringBuilder.append(getRealShot()).append(ln);
    stringBuilder.append(getShotEfficient()).append(ln);
    stringBuilder.append(getReboundEfficient()).append(ln);
    stringBuilder.append(getOffendReboundEfficient()).append(ln);
    stringBuilder.append(getDefendReboundEfficient()).append(ln);
    stringBuilder.append(getAssistEfficient()).append(ln);
    stringBuilder.append(getStealEfficient()).append(ln);
    stringBuilder.append(getBlockShotEfficient()).append(ln);
    stringBuilder.append(getFaultEfficient()).append(ln);
    stringBuilder.append(getFrequency()).append(ln);
    return stringBuilder.toString();
  }
}