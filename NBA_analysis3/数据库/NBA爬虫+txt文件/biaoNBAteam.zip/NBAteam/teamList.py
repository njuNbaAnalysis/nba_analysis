# -*- coding: utf-8 -*-  
   
import urllib2  
import urllib  
import re  
import thread  
import time  
import string
import sys

foo = open("D://NBAteam/teamList.html","r")
MainPage = foo.read()
MainPage = MainPage.decode("utf-8")
foo.close()

items = re.findall("""\<a\ target\=\"\_blank\"\ class\ \=\"team\"\ href\=\"\.\/team\/([A-Z]*)\.html\"\>\<img\ src\=\"\/image\/teamImage\/[A-Z]*\.gif\"\ width\=\"99\"\ height\=\"66\"\/\>\<div\>(.*)\<\/div\>\<\/a\>""",MainPage)

result = ""
for item in items:
    result = result + item[0] + u"-" + item[1] + "\n"

foo = open("D://NBAteam/teamList.txt","wb")
foo.write(result.encode("utf-8"))
foo.close()
